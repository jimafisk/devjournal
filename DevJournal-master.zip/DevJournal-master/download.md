---
layout: page
title: Download
permalink: /download/
---

<span class="page-tagline">Loved it? Download DevJournal</span>



<div class="post-content-download">
  <p>
    <br />
  </p>
  <div class="download">
    <center><i class="fa fa-heart"></i> Star it if you loved!</center>
    <br />
    <center>
      <iframe src="https://ghbtns.com/github-btn.html?user=hemangsk&amp;repo=devjournal&amp;type=star&amp;count=true&amp;size=large" frameborder="0" scrolling="0" width="160px" height="30px"></iframe>

      <iframe src="https://ghbtns.com/github-btn.html?user=hemangsk&amp;repo=devjournal&amp;type=fork&amp;count=true&amp;size=large" frameborder="0" scrolling="0" width="160px" height="30px"></iframe>

      <iframe src="https://ghbtns.com/github-btn.html?user=hemangsk&amp;type=follow&amp;count=true&amp;size=large" frameborder="0" scrolling="0" width="200px" height="30px"></iframe>
    </center>
  </div>
  <center>GitHub Repository
    <h2><a href="http://github.com/hemangsk/DevJournal"><i class="fa fa-github"></i></a></h2>
  </center>
  <div class="intro">
    <br />
    <p>
      Hello there! :)
      <br />
      <br /> Hemang here, developer of <span class="small-site-title">DevJournal</span> theme.
      <br /> I'm a CS sophomore at USICT, New Delhi.
      <br />
      <br />
      <a href="http://facebook.com/hemangkr"><i class="fa fa-facebook"></i></a> &nbsp; &nbsp; &nbsp;<a href="http://github.com/hemangsk"><i class="fa fa-github"></i></a>
    </p>
  </div>

</div>
